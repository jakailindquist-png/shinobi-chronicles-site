# Pinned Naruto content and sources

Inspected October 13, 2026. The pack is **Shinobi Chronicles 0.1.0**, Minecraft Java **1.20.1**, Forge **47.4.0**, Java **17**. The downloadable artifacts and hashes are recorded in `pack/mods.lock.json`; `pack/selection.json` records intentional version choices.

## Main gameplay mod

[Ninshu: Origins on Modrinth](https://modrinth.com/mod/ninshu-origins-naruto-mod) and its [author's CurseForge page](https://www.curseforge.com/minecraft/mc-mods/ninshu-origins) are the primary sources. The locked public release is **v0.4.2.5**, Modrinth version **uFvnrZzD**. Its actual file is `ninshuorigins-2.1.9-1.20.1.jar`; the different website and internal version numbers are upstream naming, not a substituted file. It provides the pack's native Naruto items, ninja combat, ability library, eye powers, tailed beasts and transformations. The author describes a mixture of canonical and original techniques, so the pack does not label all included content as canon.

The downloaded JAR is **216,599,757 bytes**. Its SHA-512 is:

```
1f500804f036678d7253a6ef3026acfa8aac896e11ab44476f7a4fa7dc83fec9ba704118cc45fecb3603267b9a8649917168baacf54eb05d73d64040c50448ce
```

`META-INF/mods.toml` identifies the namespace as `ninshuorigins`, requires Forge `[47,)` and Minecraft `[1.20.1,1.21)`, and declares these libraries:

| Library | Required range | Declared side | Locked version |
|---|---|---|---|
| [GeckoLib](https://modrinth.com/mod/geckolib) | `4.4+` | Both | `4.8.4` / `aC5KMoNg` |
| [playerAnimator](https://modrinth.com/mod/playeranimator) | `1.0.2-rc1+1.20+` | Client | `1.0.2-rc1+1.20-forge` / `xe2EVE6q` |
| [LDLib](https://modrinth.com/mod/ldlib) | `1.0.40+` | Client | `1.0.52.a` / `YSOP0G6O` |
| [Photon Editor](https://modrinth.com/mod/photon-editor) | `1.0.7+` | Client | `1.1.17` / `a7chTVuf` |

Ninshu's Modrinth version API returned an empty dependency array. The selection therefore pins all four libraries explicitly from the JAR's manifest. playerAnimator's compatible release is marked beta upstream. LDLib and Photon are also included on the server according to their own supported environments; this does not mean they implement server-only gameplay. Loader metadata establishes version ranges, not proof that every gameplay or rendering feature has been tested.

## What the inspection proves

`tools/extract_content.py` checks the locked hash, inspects the JAR with JDK `javap`, reads registry initializers and recipe outputs, and writes `docs/content-catalogue.json`. No models, textures, animations or original guide pages are copied into the addon.

The inspected build registers **713 items**, **107 entity types**, **74 weapon-prefixed items**, **118 release/learner items**, and **nine ordinary tailed-beast entities**. These are registry counts, not counts of fully implemented canon powers. Entity counts include projectiles and effect entities. The technique scan identifies **230 constructed classes** in the inspected release/jutsu code and **36 explicit placeholders**, including inherited `isFunctional() == false`. Remaining declarations are marked unverified; this scan does not certify combat behavior or exhaust the author's advertised total.

The five-tail entity uses the upstream spelling **`ninshuorigins:kukuo`**, while its learner is **`ninshuorigins:release_kokuo`**. Son Goku uses `songoku` for the entity and `release_son_goku` for the learner. Jiraiya's entity is `ninshuorigins:jiraya`. These IDs come from actual registration calls rather than guessed names.

All nine beast records, native item names, recipe references, inspected technique classes and unlock hints are in the catalogue. Re-run extraction after changing the Ninshu pin; IDs and feature status can change.

## Native progression and the custom pack

The pinned JAR includes a detailed native guide, accessible through `ninshuorigins:ninja_guide`. It distinguishes usable systems, partial work, planned previews and map-supplied content. Read it together with release tooltips for current requirements.

- Native identity creation, chakra, JP/SP/MP, clan requirements and learned techniques belong to Ninshu. The addon story route and mission credits do not replace those systems.
- Real native Kakashi and Jiraiya are placed in the custom world so their original Chidori, Rasengan, summoning and Frog Sage interactions can be reached. The addon does not skip their prerequisites or pretend that original story dialogue grants a native technique.
- The nine original sanctuary trials use actual beast entity types. A dossier entry or trial token does not seal a beast or grant native Jin Bond.
- The native guide identifies unfinished Jin Bond training, an incomplete Chakra Cloak feature, unfinished release branches, and weapons that currently offer a model and ordinary statistics without their full fictional powers. A release item being present does not prove that every technique it lists works.
- Juubi and Reibi learner items are registered, but this build has no matching beast entity. The Ten-Tails is not presented as a verified tenth summonable sibling boss.

The addon supplies an original compressed Naruto-inspired atlas and narrative encounters. It does not include a separately licensed Naruto fan map or claim that invented distances and unseen interiors are official geography.

## Distribution and attribution

Ninshu is **All Rights Reserved**. Its authors prohibit unauthorized redistribution and asset reuse. The `.mrpack` references the original author-hosted download and hash; it does not embed Ninshu's JAR or copy its art. The local inspection cache is a development download and is excluded from release packaging. Public server monetization is outside this pack's permission grant; consult the [author's current terms](https://www.curseforge.com/minecraft/mc-mods/ninshu-origins) directly.

Photon's current project page describes a custom license while this pinned older JAR's manifest says GPL-3.0. The lock preserves the publisher's current project license identifier and URL without attempting to resolve that discrepancy. It also downloads from the author's original host rather than redistributing an altered library. Each other dependency retains its own license and attribution in the lock and generated credits.

The other locked projects provide recipe browsing, tooltips, maps, inventory controls, accessibility of key bindings, advancement UI, rendering/memory optimizations, ambient audio and optional shaders. [e4mc](https://modrinth.com/mod/e4mc) supplies internet access to a host's open LAN game. No One Piece gameplay, ship physics, sailing or One Piece map dependency is included.
