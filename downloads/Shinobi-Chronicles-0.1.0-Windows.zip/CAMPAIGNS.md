# Shinobi field campaigns

Five village allegiances offer 54 chapters each: three home-village induction missions followed by the same 51-chapter story chronology. The rogue route has 14 original chapters. These are 284 route-specific records, not 284 distinct story arcs. The player is an original support shinobi; dialogue and assignments are original fan adaptations. Spoilers cover Naruto and Shippuden through the Fourth Shinobi World War.

## What missions actually do

Zabuza and Orochimaru encounters are optional native trials because their real native attributes and jutsu can overwhelm an early character. Completing one adds 12 credits when that chapter is reported; skipping it does not award the bonus. Later Pain, Danzo, White Zetsu and War Obito battles are required. Survival/adventure characters visit generated locations, turn in exact inventory quantities, complete server-checked focus or footwork lessons, and fight explicitly labeled native combat retellings where a real entity exists. A visit is not completion: every listed requirement must be met before reporting beside an owner-bound liaison. Missing reward items fail without spending inventory. Each chapter advances once. Aid gives contact trust and local goodwill; ambition gives village influence and four extra credits. Both choices advance the same authored chronology.

Field titles are add-on achievements. They do not overwrite native rank, clan, bloodline, chakra or jutsu. Lore mentions of unscripted events are explicitly identified; every scene, death, transformation, dimension and canonical ending is not simulated. NPC liaisons and recurring rivals are original characters rendered with vanilla villager/vindicator models.

## Commands

`/story` shows objectives. `/story join leaf|sand|mist|cloud|stone|rogue` makes a persistent allegiance choice. `/story embark` provides one initial journey and sets a safe respawn. `/story contact` calls your liaison to dry ground. `/story train` starts the current field lesson at its destination, beside your liaison. `/story encounter` starts the listed native encounter. `/story finish aid|ambition` reports completion. `/story travel <atlas_id>` spends 8 base credits, reduced by relationship discounts, to revisit an explored location.

Focus requires 200 consecutive crouched ticks on ground within four blocks of the start. Footwork requires 80 horizontal blocks of movement at the destination, excluding passengers, gliding, water movement and large single-tick displacements. Leaving the destination or changing chapter cancels the lesson; travel cancels it. These lessons do not claim to detect whether a specific native jutsu was cast.

## Chronological Leaf reference

### 1. Enrollment and the shinobi code

Begin as an original Leaf academy student. Study the difference between a mission objective and a promise to protect a teammate; this field record does not replace the native character creator.

Destination: `academy`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 8 × `minecraft:bread` + 8 credits.

### 2. Footwork before firepower

Meet your liaison at the training grounds and practice moving while maintaining awareness. Clan abilities and chakra remain governed by Ninshu: Origins.

Destination: `training_ground`. Lesson: footwork. Native encounter: `none`. Delivery: 12 × `minecraft:oak_log`. Reward: 4 × `ninshuorigins:weapon_kunai` + 8 credits.

### 3. A bowl and a village

A shinobi belongs to a community as well as a squad. Bring provisions to an original contact near Ichiraku and earn your first field commission.

Destination: `ichiraku`. Lesson: none. Native encounter: `none`. Delivery: 12 × `minecraft:bread`. Reward: 4 × `ninshuorigins:ramen` + 8 credits. Field-title unlock: **Genin field commission**.

### 4. Team Seven departs

Team Seven takes on an escort assignment that proves more dangerous than advertised. Your separate support squad assembles bridge-builder supplies and follows their route.

Destination: `konoha`. Lesson: none. Native encounter: `none`. Delivery: 8 × `minecraft:iron_ingot`. Reward: 8 × `ninshuorigins:weapon_shuriken` + 8 credits.

### 5. The Land of Waves

Tazuna is building a bridge intended to free the Land of Waves from economic control. Establish a supply post for the workers without claiming to take Team Seven’s place.

Destination: `wave`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:oak_planks`. Reward: 8 × `minecraft:bread` + 8 credits.

### 6. Control on the riverbank

Kakashi’s tree-climbing exercise teaches controlled chakra application. Practice a stillness drill at your mission camp; the drill is a field lesson, not a simulated native wall-walking unlock.

Destination: `wave`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_ninjutsu` + 10 credits.

### 7. Mist at the bridge

Zabuza and Haku confront Team Seven at the bridge. This encounter uses the installed Zabuza entity to retell part of that conflict; Haku’s mirrors and the entire bridge sequence are not scripted.

Destination: `wave`. Lesson: none. Native encounter: `ninshuorigins:zabuza` (optional +12 credits). Delivery: 16 × `minecraft:bread`. Reward: 8 × `ninshuorigins:weapon_kunai` + 10 credits.

### 8. The written examination

The Chunin Exams test judgment and teamwork as well as technique. Submit a field report and practice composure; this is an original examination assignment.

Destination: `academy`. Lesson: focus. Native encounter: `none`. Delivery: 16 × `minecraft:paper`. Reward: 1 × `ninshuorigins:questscroll` + 10 credits.

### 9. The Forest of Death

The second examination takes candidates into the Forest of Death with Heaven and Earth scrolls. Scout the clearing and supply your squad; this build does not consume a guessed copy of a protected native quest scroll.

Destination: `forest_of_death`. Lesson: footwork. Native encounter: `none`. Delivery: 16 × `minecraft:cooked_beef`. Reward: 4 × `ninshuorigins:weapon_smokebomb` + 10 credits.

### 10. Preliminary bouts

The preliminary matches reveal very different fighting styles. Complete a footwork drill and prepare a supply cache rather than replacing the canonical match winners.

Destination: `chunin_arena`. Lesson: footwork. Native encounter: `none`. Delivery: 12 × `minecraft:iron_ingot`. Reward: 1 × `ninshuorigins:release_taijutsu` + 10 credits.

### 11. Before the finals

Naruto trains under Jiraiya while the village prepares for the finals. Your field lesson emphasizes concentration before testing any native summoning or chakra techniques.

Destination: `training_ground`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:weapon_fumashuriken` + 10 credits.

### 12. The Konoha invasion

Orochimaru’s invasion interrupts the examination. Face his native entity in a combat retelling while your original squad supports evacuation; the Third Hokage’s canonical fate is unchanged.

Destination: `chunin_arena`. Lesson: none. Native encounter: `ninshuorigins:orochimaru` (optional +12 credits). Delivery: 24 × `minecraft:bread`. Reward: 4 × `ninshuorigins:weapon_explosivetag` + 12 credits.

### 13. After the invasion

The village tends its wounded and mourns its losses. Deliver medical materials and record the responsibilities of a field leader.

Destination: `hospital`. Lesson: none. Native encounter: `none`. Delivery: 16 × `minecraft:white_wool`. Reward: 8 × `minecraft:golden_carrot` + 12 credits. Field-title unlock: **Chunin field commission**.

### 14. Searching for the Fifth

Jiraiya and Naruto search for Tsunade to become the next Hokage. Your courier assignment supplies a roadside rendezvous; the hot-spring settlement represents travel country, not an exact canonical meeting coordinate.

Destination: `hot_water`. Lesson: none. Native encounter: `none`. Delivery: 20 × `minecraft:cooked_beef`. Reward: 6 × `ninshuorigins:ramen` + 12 credits.

### 15. Shape transformation

Rasengan training concerns chakra shape transformation, rather than an elemental release by itself. Practice control and return to native technique progression for the actual jutsu.

Destination: `training_ground`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_ninjutsu` + 12 credits.

### 16. The retrieval team

Sasuke leaves the Leaf seeking power from Orochimaru. Shikamaru leads the retrieval team; your separate squad follows the supply trail toward Sound territory.

Destination: `sound`. Lesson: footwork. Native encounter: `none`. Delivery: 24 × `minecraft:bread`. Reward: 6 × `ninshuorigins:weapon_smokebomb` + 12 credits.

### 17. The first Valley of the End

Naruto and Sasuke fight at the statues of Hashirama and Madara. Survey the battlefield after the confrontation; this mission neither guarantees Sasuke’s return nor rewrites the result.

Destination: `valley_of_end`. Lesson: none. Native encounter: `none`. Delivery: 20 × `minecraft:paper`. Reward: 8 × `ninshuorigins:weapon_kunai` + 12 credits.

### 18. The promise survives

The retrieval mission leaves teammates injured and Naruto’s promise unresolved. Deliver recovery supplies and choose what your report says about loyalty.

Destination: `hospital`. Lesson: none. Native encounter: `none`. Delivery: 20 × `minecraft:white_wool`. Reward: 8 × `ninshuorigins:ramen` + 14 credits.

### 19. Training beyond the village

Naruto’s journey with Jiraiya separates Part I from Shippuden. Complete your own field-training interval; there is no real-time multi-year wait and no automatic native stat increase.

Destination: `training_ground`. Lesson: footwork. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_taijutsu` + 14 credits.

### 20. The Kazekage is taken

Gaara’s capture brings the Leaf and Sand into a rescue operation. Arrive with supplies for the Sand medical teams and the pursuit squad.

Destination: `suna`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:white_wool`. Reward: 1 × `ninshuorigins:release_medical` + 14 credits.

### 21. Akatsuki’s cave

The rescue teams converge on an Akatsuki hideout while the extraction ritual threatens Gaara. Secure provisions and examine the approach; the complete puppet duel and sealing ritual are not automated here.

Destination: `akatsuki_hideout`. Lesson: footwork. Native encounter: `none`. Delivery: 20 × `minecraft:iron_ingot`. Reward: 6 × `ninshuorigins:weapon_explosivetag` + 14 credits.

### 22. A life returned

Chiyo’s sacrifice restores Gaara after the rescue. Help the survivors regroup; the player does not receive her life-restoring technique as a reward.

Destination: `suna`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:bread`. Reward: 8 × `ninshuorigins:ramen` + 14 credits.

### 23. Rendezvous at Tenchi Bridge

The new Team Kakashi follows intelligence toward a meeting at Tenchi Bridge. Scout the route and prepare a report before approaching Orochimaru’s network.

Destination: `tenchi_bridge`. Lesson: footwork. Native encounter: `none`. Delivery: 24 × `minecraft:paper`. Reward: 8 × `ninshuorigins:weapon_smokebomb` + 14 credits.

### 24. The hideout reunion

Naruto and Sakura encounter Sasuke again, but reunion does not mean reconciliation. Explore the hideout approach and support extraction; this objective does not invent a successful rescue.

Destination: `orochimaru_lair`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:cooked_beef`. Reward: 1 × `ninshuorigins:release_genjutsu` + 16 credits.

### 25. Nature transformation

Wind-nature training develops Naruto’s next advance. Practice concentration, then use Ninshu’s native learning system for the actual elemental techniques.

Destination: `training_ground`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_wind` + 16 credits.

### 26. The Fire Temple alarm

Akatsuki’s pursuit brings violence to the Fire Temple and the Leaf’s protectors. Deliver materials to the relief team and preserve an account of the damage.

Destination: `fire_temple`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:white_wool`. Reward: 12 × `ninshuorigins:weapon_kunai` + 16 credits.

### 27. The immortals’ trail

The pursuit of Hidan and Kakuzu tests the Leaf teams and leads to Asuma’s death. Your original intelligence assignment follows their trail; no substitute mob is presented as either Akatsuki member.

Destination: `hot_water`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:paper`. Reward: 8 × `ninshuorigins:weapon_explosivetag` + 16 credits.

### 28. Inheritance of the will

Shikamaru acts on what Asuma taught him while Naruto completes a new technique. Carry supplies and practice field control; native jutsu remain subject to native requirements.

Destination: `training_ground`. Lesson: focus. Native encounter: `none`. Delivery: 24 × `minecraft:cooked_beef`. Reward: 1 × `ninshuorigins:release_ninjutsu` + 16 credits. Field-title unlock: **Jonin field commission**.

### 29. A message from the Rain

Jiraiya investigates Pain in the Hidden Rain. Retrieve an original field report and record the cost of intelligence work without treating Jiraiya’s death as reversible.

Destination: `rain`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:paper`. Reward: 8 × `ninshuorigins:weapon_smokebomb` + 16 credits.

### 30. Stillness at Mount Myoboku

Naruto trains in senjutsu at Mount Myoboku. Your field drill emphasizes stillness; completing it does not itself award Sage Mode or a summoning contract.

Destination: `myoboku`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:sagescroll` + 18 credits.

### 31. Pain’s assault

Pain attacks the Leaf, and Naruto returns to defend it. Face the installed Pain entity in a combat retelling; the six-path battle, dialogue and restoration of the village are not fully scripted.

Destination: `konoha`. Lesson: none. Native encounter: `ninshuorigins:pain`. Delivery: 32 × `minecraft:white_wool`. Reward: 1 × `ninshuorigins:release_medical` + 18 credits.

### 32. The village rebuilds

The Leaf begins rebuilding after the assault. Bring construction materials and let your choices show whether relief or personal influence guides your mission reports.

Destination: `konoha`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:oak_log`. Reward: 12 × `ninshuorigins:ramen` + 18 credits.

### 33. Five Kage in the Land of Iron

The Five Kage Summit brings the great villages into a shared crisis. Carry a neutral courier brief to the snowy meeting site, where samurai protect the proceedings.

Destination: `iron`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:paper`. Reward: 16 × `ninshuorigins:weapon_kunai` + 18 credits.

### 34. Danzo’s final confrontation

Sasuke confronts Danzo after the summit. The native Danzo encounter is an isolated combat retelling; the player is not appointed Hokage and does not inherit stolen eyes from this quest.

Destination: `iron`. Lesson: none. Native encounter: `ninshuorigins:danzo`. Delivery: 24 × `minecraft:iron_ingot`. Reward: 1 × `ninshuorigins:release_genjutsu` + 18 credits.

### 35. A Cloud alliance

The Hidden Cloud is central to preparations involving Killer Bee and the Eight-Tails. Deliver alliance supplies and study the difference between a jinchuriki and the beast sealed within them.

Destination: `kumo`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:cooked_beef`. Reward: 1 × `ninshuorigins:release_lightning` + 18 credits.

### 36. The island that moves

Naruto travels to the giant turtle island under a protective mission. Survey the island’s forest and establish your own squad camp before the war reaches its next stage.

Destination: `turtle_island`. Lesson: footwork. Native encounter: `none`. Delivery: 32 × `minecraft:oak_planks`. Reward: 12 × `ninshuorigins:ramen` + 20 credits.

### 37. A confrontation within

Naruto’s struggle with the Nine-Tails involves inner conflict and his family’s history. Complete a control lesson; tailed-beast trial records are distinct from native jinchuriki mechanics.

Destination: `turtle_island`. Lesson: focus. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_ninjutsu` + 20 credits.

### 38. Bee’s rhythm

Killer Bee’s partnership with Gyuki shows a relationship built beyond simple captivity. Practice movement and return to native systems for any actual chakra-mode progression.

Destination: `turtle_island`. Lesson: footwork. Native encounter: `none`. Delivery: 8 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_kenjutsu` + 20 credits.

### 39. Stone logistics

The Allied Shinobi Forces draw on villages that once fought each other. Your liaison carries a supply allocation to the Hidden Stone, an original support mission within the wartime alliance.

Destination: `iwa`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:iron_ingot`. Reward: 1 × `ninshuorigins:release_earth` + 20 credits.

### 40. Mist dispatch

The Hidden Mist joins the alliance with its own troubled history and changing leadership. Deliver provisions and learn why the Seven Ninja Swordsmen’s weapons have distinct identities.

Destination: `kiri`. Lesson: none. Native encounter: `none`. Delivery: 24 × `minecraft:cooked_cod`. Reward: 1 × `ninshuorigins:release_water` + 20 credits.

### 41. Sand mobilization

Gaara addresses shinobi divided by old grievances. Prepare your squad’s contribution to the allied effort; village allegiance persists while the mission supports a common cause.

Destination: `suna`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:bread`. Reward: 2 × `ninshuorigins:weapon_fumashuriken` + 20 credits.

### 42. At the allied front

The Fourth Shinobi World War begins against forces that include White Zetsu and reincarnated shinobi. Establish an original aid station and receive a wartime field commission.

Destination: `war_battlefield`. Lesson: none. Native encounter: `none`. Delivery: 32 × `minecraft:white_wool`. Reward: 12 × `ninshuorigins:weapon_explosivetag` + 22 credits. Field-title unlock: **Allied division operative**.

### 43. Infiltration at the perimeter

White Zetsu infiltration threatens trust between allies. Fight the installed White Zetsu entity and deliver your report; this encounter does not claim to implement perfect identity detection.

Destination: `war_battlefield`. Lesson: none. Native encounter: `ninshuorigins:white_zetsu`. Delivery: 24 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_medical` + 22 credits.

### 44. The reanimated swordsman

The war forces shinobi to face fighters summoned through Impure World Reincarnation. Revisit Zabuza’s combat model as a retelling; sealing the reincarnated army is not simulated by killing an ordinary entity.

Destination: `war_battlefield`. Lesson: none. Native encounter: `ninshuorigins:zabuza` (optional +12 credits). Delivery: 32 × `minecraft:iron_ingot`. Reward: 16 × `ninshuorigins:weapon_kunai` + 22 credits.

### 45. A medic’s resolve

Medical support keeps the alliance fighting. Visit the fan interpretation of Shikkotsu Forest and deliver treatment supplies; its exact unseen canonical layout is not asserted.

Destination: `shikkotsu_forest`. Lesson: focus. Native encounter: `none`. Delivery: 40 × `minecraft:white_wool`. Reward: 1 × `ninshuorigins:release_medical` + 22 credits.

### 46. The masked opponent

The conflict exposes Obito’s identity and the personal history behind the war. Face the verified War Obito entity in a combat retelling alongside your own squad’s assignment.

Destination: `war_battlefield`. Lesson: none. Native encounter: `ninshuorigins:warobito`. Delivery: 16 × `minecraft:golden_carrot`. Reward: 16 × `ninshuorigins:weapon_explosivetag` + 22 credits.

### 47. The Ten-Tails crisis

The Ten-Tails raises the scale of the war beyond ordinary missions. Carry emergency supplies across the front; this chapter does not replace a full Ten-Tails transformation or raid simulation.

Destination: `war_battlefield`. Lesson: footwork. Native encounter: `none`. Delivery: 48 × `minecraft:cooked_beef`. Reward: 1 × `ninshuorigins:release_ninjutsu` + 22 credits.

### 48. The alliance holds

The alliance keeps fighting through loss and exhaustion. Break a White Zetsu incursion and supply the people holding the relief corridor.

Destination: `war_battlefield`. Lesson: none. Native encounter: `ninshuorigins:white_zetsu`. Delivery: 48 × `minecraft:bread`. Reward: 16 × `ninshuorigins:ramen` + 24 credits.

### 49. Records of the sealing arts

The Uzumaki homeland’s ruins provide context for a tradition of sealing arts. Your detour is an original field study, not a claim that the war’s heroes made this trip at this moment.

Destination: `uzushio_ruins`. Lesson: focus. Native encounter: `none`. Delivery: 40 × `minecraft:paper`. Reward: 2 × `ninshuorigins:questscroll` + 24 credits.

### 50. The serpent’s legacy

Senjutsu and forbidden research shape several wartime confrontations. Explore the fan interpretation of Ryuchi Cave; this field study does not grant snake Sage Mode or alter Kabuto’s canonical defeat.

Destination: `ryuchi_cave`. Lesson: focus. Native encounter: `none`. Delivery: 32 × `minecraft:iron_ingot`. Reward: 1 × `ninshuorigins:sagescroll` + 24 credits.

### 51. The Infinite Tsukuyomi

Madara’s plan reaches the Infinite Tsukuyomi and the conflict changes again. Preserve an original evacuation record; the global dream, Kaguya’s dimensions and their exact battles are not scripted here.

Destination: `war_battlefield`. Lesson: none. Native encounter: `none`. Delivery: 48 × `minecraft:paper`. Reward: 1 × `ninshuorigins:release_genjutsu` + 24 credits.

### 52. The war’s conclusion

Team Seven’s actions bring the final otherworldly conflict to its conclusion. Your mission supports the survivors and records the aftermath rather than replacing the canonical sealing outcome.

Destination: `war_battlefield`. Lesson: none. Native encounter: `none`. Delivery: 48 × `minecraft:white_wool`. Reward: 1 × `ninshuorigins:release_ninjutsu` + 24 credits.

### 53. The final Valley of the End

Naruto and Sasuke meet again for their final confrontation. Revisit the valley and complete a quiet field lesson after the battle; reconciliation remains their story.

Destination: `final_valley`. Lesson: focus. Native encounter: `none`. Delivery: 48 × `minecraft:paper`. Reward: 3 × `ninshuorigins:weapon_fumashuriken` + 24 credits.

### 54. A road toward peace

Return to the Leaf after the Fourth War and close your squad’s chronicle. Your village loyalties, relationships, learned native techniques and recurring rivals continue in the sandbox.

Destination: `konoha`. Lesson: none. Native encounter: `none`. Delivery: 48 × `minecraft:bread`. Reward: 24 × `ninshuorigins:ramen` + 26 credits. Field-title unlock: **Veteran of the alliance**.

## Other village openings

### Hidden Sand

Contact: Liaison Saki. Hidden Sand allegiance: three home-village induction missions, then a 51-chapter shared chronicle from the Land of Waves through the Fourth War. Original support assignments and labeled native combat retellings.

- **Academy of the Hidden Sand** at `suna`. Begin as an original Hidden Sand recruit. Your first lesson records mission discipline; this allegiance belongs to the add-on and does not force the native character creator.
- **Village fieldcraft** at `suna`. Your home liaison teaches movement and observation before sending you abroad. Practice footwork and assemble equipment for an exchange assignment.
- **A village and its people** at `suna`. Provision your home squad, then depart on an original exchange chronicle that follows the major events of Naruto. The shared route visits Leaf-centered events without claiming your character was a member of Team Seven.

### Hidden Mist

Contact: Liaison Nami. Hidden Mist allegiance: three home-village induction missions, then a 51-chapter shared chronicle from the Land of Waves through the Fourth War. Original support assignments and labeled native combat retellings.

- **Academy of the Hidden Mist** at `kiri`. Begin as an original Hidden Mist recruit. Your first lesson records mission discipline; this allegiance belongs to the add-on and does not force the native character creator.
- **Village fieldcraft** at `kiri`. Your home liaison teaches movement and observation before sending you abroad. Practice footwork and assemble equipment for an exchange assignment.
- **A village and its people** at `kiri`. Provision your home squad, then depart on an original exchange chronicle that follows the major events of Naruto. The shared route visits Leaf-centered events without claiming your character was a member of Team Seven.

### Hidden Cloud

Contact: Liaison Ren. Hidden Cloud allegiance: three home-village induction missions, then a 51-chapter shared chronicle from the Land of Waves through the Fourth War. Original support assignments and labeled native combat retellings.

- **Academy of the Hidden Cloud** at `kumo`. Begin as an original Hidden Cloud recruit. Your first lesson records mission discipline; this allegiance belongs to the add-on and does not force the native character creator.
- **Village fieldcraft** at `kumo`. Your home liaison teaches movement and observation before sending you abroad. Practice footwork and assemble equipment for an exchange assignment.
- **A village and its people** at `kumo`. Provision your home squad, then depart on an original exchange chronicle that follows the major events of Naruto. The shared route visits Leaf-centered events without claiming your character was a member of Team Seven.

### Hidden Stone

Contact: Liaison Iori. Hidden Stone allegiance: three home-village induction missions, then a 51-chapter shared chronicle from the Land of Waves through the Fourth War. Original support assignments and labeled native combat retellings.

- **Academy of the Hidden Stone** at `iwa`. Begin as an original Hidden Stone recruit. Your first lesson records mission discipline; this allegiance belongs to the add-on and does not force the native character creator.
- **Village fieldcraft** at `iwa`. Your home liaison teaches movement and observation before sending you abroad. Practice footwork and assemble equipment for an exchange assignment.
- **A village and its people** at `iwa`. Provision your home squad, then depart on an original exchange chronicle that follows the major events of Naruto. The shared route visits Leaf-centered events without claiming your character was a member of Team Seven.

## Missing-nin alternate route

### 1. A missing-nin’s choice

Begin an explicitly alternate original route as a missing-nin. You do not become an Akatsuki member or replace a canon character; your first decision is how to survive outside a village.

Destination `sound`; lesson focus; native encounter `none`; delivery 8 × `minecraft:paper`; reward 8 × `minecraft:bread` and 11 credits.

### 2. Tools without a quartermaster

Assemble a field kit through an independent Grass-country contact. The names and assignments in this route are original.

Destination `grass`; lesson none; native encounter `none`; delivery 12 × `minecraft:iron_ingot`; reward 8 × `ninshuorigins:weapon_kunai` and 12 credits.

### 3. Rain over the border

Carry food into the Rain and listen before choosing a side. Conditions here are informed by the setting; this quest does not simulate every political period simultaneously.

Destination `rain`; lesson none; native encounter `none`; delivery 24 × `minecraft:bread`; reward 8 × `ninshuorigins:ramen` and 13 credits.

### 4. The red-cloud dossier

Study reports about Akatsuki’s pursuit of the tailed beasts. An intelligence dossier is not an invitation to join or a license to command the organization.

Destination `akatsuki_hideout`; lesson none; native encounter `none`; delivery 24 × `minecraft:paper`; reward 1 × `ninshuorigins:questscroll` and 14 credits.

### 5. A forbidden threshold

Recover an original field report near Orochimaru’s hideout. Finish a control drill before handling powers whose native costs you must still satisfy.

Destination `orochimaru_lair`; lesson focus; native encounter `none`; delivery 24 × `minecraft:paper`; reward 1 × `ninshuorigins:release_genjutsu` and 15 credits.

### 6. The swordsman’s rumor

Follow a report concerning Zabuza and test yourself against his native combat model. This is a retelling, not a new canonical survival for the character.

Destination `wave`; lesson none; native encounter `ninshuorigins:zabuza`; delivery 24 × `minecraft:cooked_cod`; reward 1 × `ninshuorigins:release_kenjutsu` and 16 credits.

### 7. The waterfall refuge

An independent liaison establishes a hidden relief cache near the Waterfall. Deliver supplies and decide whether reputation matters more than quick influence.

Destination `waterfall`; lesson footwork; native encounter `none`; delivery 32 × `minecraft:oak_planks`; reward 12 × `ninshuorigins:weapon_smokebomb` and 17 credits.

### 8. The ruins of a seal

Investigate sealing traditions at the ruined Uzumaki homeland. This mission unlocks a field title, never an inherited bloodline.

Destination `uzushio_ruins`; lesson focus; native encounter `none`; delivery 32 × `minecraft:paper`; reward 2 × `ninshuorigins:questscroll` and 18 credits.

### 9. Mist without a banner

Supply an original coastal contact while the Mist navigates its own legacy. Possessing a sword does not grant membership in the Seven Ninja Swordsmen.

Destination `kiri`; lesson none; native encounter `none`; delivery 32 × `minecraft:cooked_cod`; reward 1 × `ninshuorigins:release_water` and 19 credits.

### 10. A summit beyond your authority

Observe the Land of Iron’s role as neutral summit territory. Your report does not make you a Kage or grant diplomatic control over a village.

Destination `iron`; lesson none; native encounter `none`; delivery 32 × `minecraft:paper`; reward 2 × `ninshuorigins:weapon_fumashuriken` and 20 credits.

### 11. The serpent’s cave

Explore a fan-built interpretation of Ryuchi Cave. Complete a stillness lesson and use native progression for any actual sage ability.

Destination `ryuchi_cave`; lesson focus; native encounter `none`; delivery 8 × `minecraft:paper`; reward 1 × `ninshuorigins:sagescroll` and 21 credits.

### 12. War crosses every border

The war reaches people outside the great villages too. Break a White Zetsu attack on your original relief route.

Destination `war_battlefield`; lesson none; native encounter `ninshuorigins:white_zetsu`; delivery 40 × `minecraft:bread`; reward 12 × `ninshuorigins:weapon_explosivetag` and 22 credits.

### 13. A debt to the living

Carry medical supplies to a Leaf relief contact. This voluntary act can improve local goodwill without erasing the permanent allegiance chosen at the start.

Destination `hospital`; lesson none; native encounter `none`; delivery 40 × `minecraft:white_wool`; reward 1 × `ninshuorigins:release_medical` and 23 credits.

### 14. A name you choose to keep

Close the independent chronicle with supplies for the refuge. Continue as a roaming shinobi with persistent contacts and rivals; this original ending is separate from the manga’s protagonists.

Destination `waterfall`; lesson none; native encounter `none`; delivery 48 × `minecraft:cooked_beef`; reward 20 × `ninshuorigins:ramen` and 24 credits.

## Canon orientation and sources

The chronology and broad event context are checked against the official Naruto anime catalogue and anniversary arc summaries; player missions, costs, dialogue, ranks and rewards are authored gameplay adaptations. Read the source story for complete scenes and motivations.

- [Official Naruto episode catalogue](https://naruto-official.com/en/anime/naruto1/list).
- [Official Sasuke retrieval episode summary](https://naruto-official.com/en/anime/naruto1/list/01_334).
- [Official Kazekage Rescue / Long-Awaited Reunion retrospective](https://naruto-official.com/en/news/01_1308).
- [Official Two Saviors / Five Kage retrospective](https://naruto-official.com/en/news/01_1321).
- [Official Shippuden episode catalogue](https://naruto-official.com/en/anime/naruto2/list).
