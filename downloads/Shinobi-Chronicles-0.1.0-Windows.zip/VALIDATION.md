# Validation and remaining playtest boundaries

This release is a tested build candidate for Minecraft Java 1.20.1, Forge
47.4.0 and Java 17. The checks below were run on macOS on 14 October 2026.
Windows installation and a full multiplayer playthrough still need acceptance
testing on the machines that will play the pack.

## Checks completed

- `./gradlew build runGameTestServer -PfullPack` completed with **27 of 27
  required Forge GameTests passing**. The test run loaded the pinned full mod
  set. It covers the dedicated dimension and generated landmarks, arrival
  safety, biome regions, renewable village gardens, actual chunk persistence,
  all nine constructible native beast entities, native market registration,
  protected mentor placement and recovery, campaign graph and allegiance,
  mission claim conditions, credit and shop transactions, beast field studies,
  co-op mission phase, NPC contacts, rivals and a local AI-dialogue mock.
- `tools/validate_pack.py` checked all 27 downloaded mod files against their
  pinned sizes and SHA-1/SHA-512 hashes. It checked Forge dependency ranges,
  native item and entity IDs, content-catalogue counts, addon resources and
  archive contents. Third-party jars are downloaded from their published
  Modrinth URLs when the pack is imported; only the original addon jar is
  included in the archive.
- An isolated, offline, production-format macOS client with the exact pinned
  mod files reached **“Shinobi Chronicles title screen ready”** in its log.
  Minecraft then finished its initial resource/datapack load. This smoke test
  did not use a Minecraft account, public server or user save.
- The standalone field compendium loaded in a browser; search, category
  filtering and atlas marker navigation were exercised.

## Limits to check during play

- This is an original compressed Minecraft interpretation of the Naruto world,
  with 33 fixed destinations. It is not a one-to-one copy of anime geography or
  set design. Individual interiors and long-distance journeys should be
  explored in a normal Survival save before treating them as final.
- The pinned Ninshu artifact logs **37 missing item-model JSON references**
  during client startup. The client still reached the title screen, but some
  native items or armor may display a missing-model appearance. These missing
  references are within the third-party content used by the pack; a registered
  item or technique is not proof that its visuals or behavior are complete.
- The source mod itself leaves some release techniques, clan acquisition paths,
  legendary weapon effects and Jin Bond progression unfinished. Our story,
  shop and beast trials do not silently bypass those native prerequisites. See
  [CONTENT.md](CONTENT.md) for the exact gameplay boundaries.
- Native mentor lessons and all nine beast fights have not been completed
  end-to-end by a human player. GameTests validate registration, spawning and
  progression guards; they do not validate combat balance, every animation,
  every model, or a full mastery path.
- e4mc LAN play between separate networks, Windows Prism import, Java/memory
  settings on the target PC, and optional local-AI setup have not been tested
  end-to-end. The local AI bridge was tested with a mock response, not a live
  model server. Core NPC and quest dialogue works with AI disabled.

When reporting a bug, include the location or mission ID, steps to repeat it,
and the relevant `latest.log` from the game's instance. The source and pinned
mod list are in the adjacent `MOD-SOURCES.md` and in the project `README.md`.
