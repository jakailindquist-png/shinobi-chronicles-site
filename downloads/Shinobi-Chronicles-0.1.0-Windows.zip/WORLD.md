# Shinobi world atlas

The add-on generates an explorable Naruto-inspired dimension, `shinobi:shinobi_world`, with 33 named destinations and a fixed geography. The five great villages are built from original Minecraft geometry. Their defining architecture, climates and story locations guide the design; this is a compressed adaptation, **not an official map or a block-perfect reconstruction of every anime shot**.

The map covers roughly 5,700 blocks east to west and 5,300 blocks north to south around its named locations. Wilderness continues beyond those coordinates. Each location uses the same coordinates in every save, so mission instructions stay reliable. The world seed does not rearrange this atlas. Forest trails connect the central countries; the eastern sea separates island destinations. A full atlas export is bundled at `data/shinobi/locations.json`.

## Five great villages

| Village | X, Z | Arrival Y | Built identity and landmarks |
|---|---:|---:|---|
| Konohagakure | 0, 0 | 77 | A forest settlement with a circular timber wall, green main gate, red tiled houses, streets, working interiors, mission hall, academy classroom, Ichiraku counter, four stylized Hokage faces, hospital, Uchiha compounds, exam arena and Training Ground Three. |
| Sunagakure | -2100, 650 | 77 | A desert basin behind an enclosing cliff ring, with a narrow southern canyon entrance, rounded sandstone residences, Kazekage tower, puppet workshop and terracotta detailing. |
| Kirigakure | 2350, 1300 | 71 | An island city of pale round towers, muted blue roofs, canal crossings, Mizukage tower, wooden docks and a custom biome with grey mist colors. |
| Kumogakure | 1600, -1900 | 143 | A high mountain settlement with white buildings, raised cylindrical towers, stone platforms, steps and elevated bridges. |
| Iwagakure | -1800, -1600 | 115 | A stone-country settlement of ochre buildings, stacked terraces, tower districts and broad rock shoulders. |

Houses have open entrances, windows, furniture, beds, crafting tables, furnaces, barrels, bookshelves, lighting and ladders between accessible floors. The geometry is intentionally readable at Minecraft scale. Blocks and interiors are ordinary editable world blocks after generation. Direction signs use vanilla sign block entities. Eight settlements also contain irrigated community gardens with mature wheat, carrots, potatoes and sugar cane. These provide renewable food, seeds and paper ingredients without returning to the Overworld. Konoha's garden is at (65, 230); Suna's is at (-2035, 825).

Konoha's small destinations have their own map entries: `academy` (-60, 32), `ichiraku` (40, 38), `hokage_rock` (0, -180), `chunin_arena` (120, 60), `uchiha_district` (-150, -60), `hospital` (110, -70), and `training_ground` (-85, 145). Their arrival courts sit outside their main structures so travel does not place a player inside a wall.

## Story landscape

| Destination ID | X, Z | What is built |
|---|---:|---|
| `forest_of_death` | -480, 350 | Fenced perimeter, very tall persistent-leaf trees, canopy routes, stone maze fragments and a central multilevel exam tower. |
| `valley_of_end` | 540, -440 | A cut river gorge, high waterfall, opposing monumental stone shinobi and an arrival bank west of the river. |
| `wave` | 1300, 800 | A timber coastal hamlet and a 430-block Great Naruto Bridge with piers, railings and lights. |
| `rain` | -1000, -450 | Dense grey tower blocks, exposed copper-colored pipes, elevated crossings, gridded canals and a tall central tower. |
| `iron` | 300, -2000 | Snow-country summit hall, meeting benches, samurai lodgings, red torii and training court. |
| `akatsuki_hideout` | -1350, -850 | Rock-covered extraction hall with ten ritual positions and an ominous central monument. |
| `orochimaru_lair` | 750, -850 | Rock-covered laboratory complex with luminous chambers, specimen-colored tanks and iron-bar cells. |
| `sound` | 50, -900 | A principal compound with several separated hideout chambers; Sound is represented as a network rather than an invented canonical metropolis. |
| `grass` | -780, -1200 | A small frontier settlement and border mission stop. |
| `waterfall` | 350, -1250 | A great tree, waterfall curtain and sheltered houses. |
| `hot_water` | 1100, -450 | Bathhouse settlement with pools and traveler lodgings. |
| `tenchi_bridge` | -600, -750 | A wooden bridge crossing a deep gorge west of the arrival platform. |
| `fire_temple` | 620, 280 | A monastery hall, torii approach, court and multilevel pagoda. |
| `uzushio_ruins` | 1900, 200 | Broken island walls, red torii and an original spiral sealing court. |
| `turtle_island` | 2350, -800 | A **stationary** turtle-shaped island with mossy shell ribs, a head, flippers, forest canopy and a waterfall training grotto. |
| `war_battlefield` | 100, -2900 | A large scarred plain, dark stone debris and an alliance operations camp. |
| `final_valley` | 540, -440 | The same Valley of the End as the earlier rivalry destination, reused for the concluding campaign chapter. |

The official episode synopsis explicitly places Naruto and Sasuke's final clash in the same valley as their earlier conflict, so these two IDs share geography instead of inventing a second valley. See [The Final Valley, official episode synopsis](https://naruto-official.com/en/anime/naruto2/list/01_919). The Island Turtle training grotto is motivated by Naruto's Waterfall of Truth training; see the [official Volume 53 description](https://naruto-official.com/en/comics/01_135).

## Sage regions and tailed-beast trial space

| Destination | X, Z | Adaptation |
|---|---:|---|
| Mount Myoboku | 2600, -2400 | Giant red mushrooms, stylized toad monuments, a meditation pool and sage hall. |
| Ryuchi Cave | -2500, -2200 | A large stone shrine chamber, calcite formations and a stylized white serpent dais. |
| Shikkotsu Forest | -2600, 1900 | Tall humid forest, pale slug-inspired sanctuary and blue patterning. |
| Tailed Beast Training Sanctuary | -550, -2350 | An **original gameplay location**: a flat, approximately 380-block-wide dirt fighting circle with perimeter wall and an external observation lodge. |

The three sage regions' exact geographic placements are invented for this playable map. Shikkotsu in particular has limited canonical environmental detail, so its build is explicitly interpretive. Myoboku's association with Jiraiya and the toads is established in the [official Jiraiya retrospective](https://naruto-official.com/en/news/01_1643). The pack does not claim that these sanctuaries can be reached by these distances or compass bearings in canon.

The large trial clearing exists so huge native tailed-beast entities have room to move. It is not a claim that the nine beasts normally live together or spawn unsealed in one sanctuary. The center at (-550, 83, -2350) has solid ground and open headroom; markers and viewing buildings remain outside the fighting interior. Canon-associated origins and hosts belong to the separate bestiary/campaign material.

## Timeline and fidelity limits

This is a persistent adventure stage that brings together Part I and Shippuden landmarks. It does not destroy Konoha when the story reaches Pain, rebuild it later, or erase the valley statues after the final duel. Early-series, pre-Tsunade Konoha has four stylized monument faces. Later characters and missions may be present through the campaign independently of that architectural snapshot.

All buildings, terrain functions and block sculptures are original. No downloaded anime map, ripped game model or copyrighted map image is included. The fidelity priorities are recognizable silhouettes, climate, place names, landmarks and narrative function. Individual house plans, exact distances, most interiors, wilderness topography, the alliance battlefield and shrine layouts are gameplay inventions. Mist uses biome colors and ordinary weather, not volumetric animated fog. The turtle island does not move. The map does not contain a separate Kaguya dimension or Boruto-era city expansion.

## Generation and save behavior

`ShinobiChunkGenerator` runs through Minecraft's normal asynchronous chunk-generation pipeline. It writes only the chunk currently being generated. Terrain, trees and architecture are deterministic functions of world coordinates. Architecture pieces are indexed by chunk, so reaching a village does not run a command that builds the entire country at once.

The generator is registered with Forge as `shinobi:atlas`; the region-aware biome source uses the same registry name in the biome-source registry. The dimension comes from the bundled datapack JSON. The generator makes its own vegetation and landmarks rather than asking vanilla biome decoration to place villages on top of them. Ordinary mining remains possible through stone, deepslate and deposits of coal, iron, copper, gold, lapis, redstone, diamond and high-altitude emerald. These mineral distributions are gameplay choices.

There is **no chunk-load or tick-time rebuilding hook**. Once a chunk has generated, edits are normal saved Minecraft changes. Returning to a location does not replace a player's house or regenerate a destroyed village. Changes to this generator affect newly generated chunks only; a new world is the clean way to inspect a revised atlas. Arrival coordinates are initially clear, but later player construction or destructive combat can alter them; travel code should check for safe headroom without rewriting those blocks.

`WorldAtlas.LOCATIONS` is the stable campaign interface. Each location exposes `id`, `name`, `x`, `z`, `radius` and `description`. `WorldAtlas.at(player, id)` checks the correct dimension and horizontal discovery radius. `WorldAtlas.arrival(id)` provides the original safe arrival column. Aliases `leaf`, `sand`, `mist`, `cloud`, `stone`, `forest` and `valley` resolve to their full destination IDs.

The world GameTests cover unique destination IDs, every planned arrival floor and headroom, distinct landmark materials, climate regions, a clear large-beast arena, actual custom-dimension chunk generation and persistence of a player edit when the chunk is accessed again. These tests do not claim visual review of every building or a restart/unload persistence soak test.
