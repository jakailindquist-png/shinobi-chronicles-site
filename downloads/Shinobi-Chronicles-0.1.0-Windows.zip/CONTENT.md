# Chakra, ninja tools and the nine tailed beasts

Shinobi Chronicles focuses its campaign on **Naruto and Naruto: Shippuden**.
Ninshu: Origins is the content engine. Its wider catalogue also contains
Boruto, anime-only and original fan entries. A registered item is evidence that
the item exists, not that all its namesake's abilities are working.
The companion compendium lists the installed artifact's actual entries.

## Your character and native progression

Complete Ninshu's introduction and read the **Ninja Guide** supplied on first
login. Use Controls → Ninshu to inspect charge chakra, movement, jutsu selection
and use keys; use Controlling to find conflicts. The addon does not forcibly
rewrite the native clan, nature, village, eyes, chakra, skills or mastery.

Campaign allegiance chooses your mission contact and story perspective. It is
separate from Ninshu's native identity and rank. Mission credits buy curated
equipment; they are not native Ryo. Advancement through our story is not evidence
that a native jutsu was unlocked. Techniques keep their own learner, teacher,
resource and mastery requirements.

The installed mod contains learners for the five basic elements—Fire, Wind,
Lightning, Earth and Water—along with medical, taijutsu, genjutsu, kenjutsu and
ninjutsu branches. It also contains bloodline, clan, ocular and beast branches.
The existence of Wood, Ice, Sharingan, Rinnegan, sage or beast content does not
make every branch available to every new character. Check the native guide
before choosing a long progression path.

There are native mentor entities and interactions. Kakashi's native teaching
includes Chidori; Jiraiya's includes Rasengan, summoning and frog sage training.
The addon places protected representatives at its fixed training sites, while
their native interaction code decides eligibility. Teacher placement is a map
adaptation; the addon does not fake successful instruction by giving a renamed
vanilla item.

## Nine distinct dossiers

These are living chakra beings with histories, personalities and relationships.
Tail count is not used as a canonical power ranking. The host examples below
are historical Naruto/Shippuden associations, not simultaneous occupancy.

| Tails | Beast | Familiar host associations | Signature association | Field study |
|---|---|---|---|---|
| 1 | Shukaku | Gaara, Bunpuku | Sand, wind and sealing patterns | Hidden Sand |
| 2 | Matatabi | Yugito Nii | Blue flame and feline movement | Hidden Cloud |
| 3 | Isobu | Yagura; briefly Rin | Water and a heavily armored body | Hidden Mist |
| 4 | Son Goku | Roshi | Lava Release | Hidden Stone |
| 5 | Kokuo | Han | Boil Release and powerful charges | Hidden Stone |
| 6 | Saiken | Utakata | Caustic secretions and slug traits | Hidden Mist |
| 7 | Chomei | Fu | Flight and insect traits | Hidden Waterfall |
| 8 | Gyuki | Killer B; formerly Blue B | Ink, tentacles and Tailed Beast Ball | Hidden Cloud |
| 9 | Kurama | Naruto, Kushina, Mito; Minato held the Yin half | Enormous chakra and Tailed Beast Ball | Hidden Leaf |

`/shinobi beasts` opens the field desk. Study at the associated village with
`/shinobi beasts study <id>`. The accepted IDs are `shukaku`, `matatabi`, `isobu`,
`son_goku`, `kokuo`, `saiken`, `chomei`, `gyuki`, `kurama`.

After completing 12 story missions, travel to the **original Beast Sanctuary**
at X -550, Z -2350. Use `/shinobi beasts trial <id>` in Survival. Each trial
spawns the actual native beast, with its native model and combat code. Only one
trial can occupy the shared sanctuary at a time; its reservation is saved across
server restarts. Trials expire after 20 minutes of world time. Eligible nearby
allies who deal damage share victory credit. They need that beast's field study
and the same minimum mission progression. Report there with
`/shinobi beasts claim <id>` for 40 mission credits and a commemorative study seal.
Each character claims each reward once.

The trial is an original combat challenge. Defeating a beast does not canonically
earn its trust. The study seal is a commemorative amethyst item, not a container
for its chakra. **These trials do not seal a beast into the player, advance
Ninshu's Jin Bond, or unlock its transformations.**

The Ten-Tails is part of the war chronicle, not a tenth member of the nine sibling
beasts. The installed artifact has a Juubi learner entry; it does not register a
Juubi creature alongside the nine beast entities. No fake Ten-Tails boss is
substituted for it.

## Canon equipment you can earn

The curated quartermaster supplies actual native items. Standard tools include
kunai, shuriken, Fuma shuriken, explosive tags, smoke bombs and healing tags.
Weapons are gated by completed story missions and paid for in mission credits.
Trust and goodwill reduce prices. The same credit ledger survives death.

All seven named Mist swords are represented by native equipment entries:
Kubikiribocho, Samehada, Hiramekarei, Kiba, Nuibari, Kabutowari and Shibuki.
Kabutowari's listed item is the hammer component. Special mechanics are limited
by the installed mod; a model and attack statistic do not imply every anime
ability such as chakra absorption, repair, sewing, paired attacks or explosions.

Other curated equipment includes Kusanagi, Orochimaru's Kusanagi, Gunbai,
Temari's fan, Hidan's scythe, Raijin kunai, chakra blades, the White Light Chakra
Sabre, Bubblepipe, Demonic Flute, Yagura's staff and Adamantine Staff. Bashosen,
Kokinjo, Benihisago and Shichiseiken appear as late shop equipment. The relic
names do not promise a complete word-soul sealing puzzle or anime-level power.

Headbands for all five major villages and the Allied Shinobi Forces are
available. Search the compendium for the wider native clothing and cosmetics
catalogue. The curated shop avoids upstream joke weapons and original fan
weapons; these can still appear in the installed mod's general item lists.

## Known upstream limits in this pin

The jar's own guide explicitly describes unfinished features. Some release
techniques are placeholders. Several clan acquisition paths—including listed
Senju/Wood, Yuki/Ice, Kurama-clan and Jugo paths—are incomplete. Kurama **clan**
and Kurama **the Nine-Tails** are distinct entries. Normal Jin Bond training is
not implemented in the inspected version. A cloak toggle checking a bond or
mastery value is not proof of a complete transformation progression. The native
`/sevenswords` command is not a complete weapon acquisition system.

The addon provides structured exploration, mission progression, protected
mentors, a real equipment economy and beast encounters around that content.
It does not claim to repair every unfinished upstream ability. Runtime tests
verify registered items and creature construction; individual combat animations,
damage balance, teaching chains and high-level forms still need playtesting.

## Sources and adaptation boundaries

Lore references: the official [Naruto anime catalogue](https://naruto-official.com/en/anime/naruto1),
[Shippuden catalogue](https://naruto-official.com/en/anime/naruto2),
[Five Kage episode](https://naruto-official.com/en/anime/naruto2/list/01_643),
and [official Kurama database entry](https://naruto-official.com/en/news/01_1896).
The chapter-referenced [Tailed Beast overview](https://naruto.fandom.com/wiki/Tailed_Beast)
and individual beast entries support the host and affinity cross-checks.
The official Kurama database includes Boruto spoilers; the playable chronicle
does not continue into that period.

Installed behavior is checked against Ninshu's published artifact, actual item
and entity registration bytecode, release implementation classes and bundled
guide. MOD-SOURCES.md records the exact pin and source links. World coordinates,
architecture, original liaisons, recurring rivals, mission cargo, credit prices,
sanctuary trials and alternate allegiances are fan gameplay adaptations.
